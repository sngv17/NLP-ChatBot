# Chatbot widget using HTML, CSS & JavaScript

## Customisation 📝 

The Chatbot widget can be customised to suit your individual requirements too. Follow in-code documentation to customise the widget easily and fit other purposes or add features under the License agreement of this opensource project.

## Demo 🔗

<img src="https://media.giphy.com/media/1QLWLvXxS3F7CMB9mD/giphy.gif" width="400" height="350" />

